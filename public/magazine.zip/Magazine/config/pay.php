<?php
    return  [
        'mch_id' => '1385937402',
        'AppID' => 'wxe2308e42d3c2048a',
        'AppSecret' => '0809b636294c98237d2c977891ff0de0',
        'KEY' => 'eV2IYTvrHvXrBCdNoBHRwnqiTMHqm1g7',
        'NOTIFY' => 'http://www.ynresearch.net/notify_url',
        'UOURL' => 'https://api.mch.weixin.qq.com/pay/unifiedorder',
    ];