// 登陆 ,注册 忘记密码头部
document.writeln("<div class=\'sxts\' id=\'sxts\' >");
document.writeln("			<div id=\'sxts_main\'>");
document.writeln("				<p >本网是<a href=\'http://www.sino-ma.org/\' target=\'_blank\'>管理会计网（www.sino-ma.org）</a>的升级版，试运行阶段新老网站将并行至9月30日，网站正在努力完善中，若给大家造成不便，敬请谅解。");
document.writeln("				</p>");
document.writeln("				<p >如您在浏览网站过程中发现任何问题或有好的建议，欢迎反馈给我们！（<a href=\'https://www.wjx.top/jq/44428639.aspx\'>点击反馈</a>）</p>");
document.writeln("			</div>");
document.writeln("		</div>");
document.writeln("<div class=\'gmheader\' id=\'gmheader\'>");
document.writeln("			<div class=\'gmheaderD_pcD\' id=\'gmheaderD_pcD\'>");
document.writeln("				<div class=\'Gmheader_pcB\' id=\'Gmheader_pcB\'>");
document.writeln("					<a href=\'/index.html\' class=\'loge\'><img src=\'./img/logo2.png\' alt=\'\'></a>");
document.writeln("				</div>");
document.writeln("					<a href=\'./index.html\' class=\'fhsy\'>返回首页</a>");
document.writeln("				<div class=\'clear\'></div>");
document.writeln("			</div>");
document.writeln("		</div>");
document.writeln("		<script type=\'text/javascript\' src=\'js/jquery-1.11.1.min.js\'></script>");
document.writeln("		<script src=\'./picJs/tuichu.js\' type=\'text/javascript\' charset=\'utf-8\'></script>");
