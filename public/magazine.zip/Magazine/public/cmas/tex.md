home   主页   特稿改观察 
industry 业界
observe 观察
theory  理论   理论前沿改前沿  案例前沿改案例   frontierlist/列表
case   案例  特稿 改专访 （5-7）
Visit  访问  特稿改案例（5-7）
technology   技术 猜你喜欢显示3条   案例前沿改理论（5-7）
activity  活动    专业内容 干货改（）
activity  活动内容
Land  登陆 
case Visit technology  公用  technology  一个js


//xinwenimg    新闻内容图片
首页  文字链接
畅想大智移云时代的管理会计创新——首届校企讲坛圆满落幕    theory_C02.html 
<!-- 荐读 -->
“互联网+智慧税务”时代，企业应补什么课？               jiandu02.html


理论
管理会计信息化的新思维    lilun01.html  作者：李彤
立足共享服务 构建集团级企业数据中心  lilun02.html  作者：屈涛
在线商城＋财务共享：重塑电商模式下的采购流程 lilun04.html  作者：元年
“后金税三期”时代，企业税务管理应何去何从？    lilun05.html 作者：元年


案例
S集团:以成本分析为中心的BI平台搭建(上)   anli01.html   元年
S集团:以成本分析为中心的BI平台搭建(下)   anli02.html   元年
基于价值链理论 构建成本管理体系   anli03.html  李佳洁、商广同

技术
内存计算驱动企业管理升级   jishu01.html   中国软件网
贾小强：大数据时代的计划预测管理  jishu02.html 贾小强
财务智能化的创新框架  jishu03.html  董洁 

观察/guancha
提升赋职能力 强化责任担当  guancha01.html 作者：李连清
管理会计要助力中国经济实现高质量发展    guancha02.html 作者：刘绍娓
践行管理会计 促进价值提升  guancha03.html 作者：罗乾宜


2019-6-1 
技术页面少3个内容
猜你喜欢
新闻02
案例03
荐读01
观察
少三个内容
热搜词


2019-7-24
新闻  文章猜你喜欢
热点  文章猜你喜欢
登陆页面   找回密码