login = $('#login').html();
ID = $('#id').val();
num = $('.Stock_text').html();




// 购买页面
            if ( num == 0) {
                $('.purchase').attr("disabled", true);
                $('.button').attr("disabled", true);
                // $('.plus').attr("disabled",true);
                $('.purchase').css({
                    "background": "#eaeaea",
                    "color": "#000"
                })
                $("#join").css({
                    "border": "none"
                })
            }
            // 选择版本
            $('.details_guig .xz a').click(function() {
                $(this).addClass("Selection").siblings().removeClass("Selection");
                var Selectioncen = $('.Selection').text();
                var seleCen = $('.Selection .lb').text();
            })
         
            //
            // 选择期刊 半年 或者全年
            $(".SubscribeMoreP input:checkbox").click(function() {
                //设置当前选中checkbox的状态为checked
                $(this).attr("checked", true);
                $(this).siblings().attr("checked", false); //设置当前选中的checkbox同级(兄弟级)其他checkbox状态为未选中
                var json = [];
                $('.SubscribeMoreP input:checked').each(function() {
                    var xzid = $(this).attr('id'); //选中id
                    // console.log(xzid)
                    json.push(xzid)
                })

            });
            $(".plus").click(function() { //购物车+
                centent_number = $('.centent_number').val();
                var vb = parseInt(centent_number) + 1;
                if (vb > num) {
                    vb = num
                    $(".centent_number").val(vb);
                    $('.details_Number .kuc').show();
                    console.log("库存不足！")
                } else {
                    $('.details_Number .kuc').hide();
                    $(".centent_number").val(vb);
                }
                $(".centent_number").val(vb);
            })
            $(".reduce").click(function() { //购物车-
                centent_number = $('.centent_number').val();
                $('.details_Number .kuc').hide();
                var vb = parseInt(centent_number) - 1;
                $(".centent_number").val(vb);
                if (vb < 1) {
                    vb = 1
                    $(".centent_number").val(vb);
                }
            })
            // 监听回车
            $(".centent_number").keypress(function() {
                var centent_number = $('.centent_number').val();
                if (centent_number > num) {
                    $('.details_Number .kuc').show();
                } else if (centent_number <= 0) {
                    $('.details_Number .kuc').hide();
                    $('.centent_number').val(centent_number)
                }
            });
            // 立即订阅
            $('.immediately').click(function() {
                // 判断是否登陆
                if (login == undefined) {
                    layui.use('layer', function() {
                        layui.use('layer', function() {
                            layer.msg('登陆后可购买', {
                                skin: 'demo-class',
                                time: 2000 //2秒关闭（如果不配置，默认是3秒）
                            }, function() {
                                location.href = '/loadLogin';

                            });
                        })
                    })
                } else {

                    if (ID == 15) {
                        location.href = 'https://k.weidian.com/Ab4Iu0GT';
                    } else if (ID == 14) {
                        location.href = 'https://k.weidian.com/TzBCa3qa ';

                    } else {
                        alert("补货中！！！！")
                    }
                    // 					var m_id = e.data.magazine.m_id; //mid
                    // 					var p_id = $('.SubscribeMoreP input:checked').attr('id'); //选中pid
                    // 					var num = $(".centent_number").val(); // 数量
                    // 					var seleCen = $('.Selection .lb').text(); //最后的数量 type 类型 2为平装
                    // 					if (seleCen == "平装") {
                    // 						seleCen = 2;
                    // 					}
                    // 					var json = [];
                    // 					var flag = $('.SubscribeMoreP input:checked').prop("checked"); //是否选中3期或者6期
                    // 					if (flag == true) {
                    // 						console.log("true选中")
                    // 						var obj = {
                    // 							"pid": parseFloat(p_id), //
                    // 							"num": parseFloat(num),
                    // 							"type": seleCen,
                    // 							"dvfq": 1,
                    //
                    // 						}
                    // 						json.push(obj)
                    // 						var obj = {
                    // 							"mid": parseFloat(m_id), //
                    // 							"num": parseFloat(num),
                    // 							"type": seleCen,
                    // 							"dvfq": 1,
                    // 						}
                    // 					} else { //没有选中 mid
                    // 						console.log("没有选中")
                    // 						var obj = {
                    // 							"mid": parseFloat(m_id), //
                    // 							"num": parseFloat(num),
                    // 							"type": seleCen,
                    // 							"dvfq": 1,
                    // 						}
                    // 					}
                    // 					json.push(obj)
                    // 					console.log(token)
                    // 					$.ajax({
                    // 						type: "POST",
                    // 						url: 'http://www.ynresearch.net/careorder',
                    // 						headers: {
                    // 							"TOKEN": token
                    // 						},
                    // 						data: {
                    // 							json: JSON.stringify(json)
                    // 						},
                    // 						success: function(data) {
                    // 							console.log(data);
                    // 							location.href = './order.html';
                    // 						},
                    // 						error: function() {
                    // 							console.log("错的");
                    // 						}
                    // 					})
                }
            })



            // 加入购物车
            $('.join').click(function() {
                if (login == undefined) {
                    layui.use('layer', function() {
                        layui.use('layer', function() {
                            layer.msg('登陆后可购买', {
                                skin: 'demo-class',
                                time: 2000 //2秒关闭（如果不配置，默认是3秒）
                            }, function() {
                                location.href = '/loadLogin';

                            });
                        })
                    })
                } else {
                    // 数量
                    if (ID == 15) {
                        location.href = 'https://k.weidian.com/Ab4Iu0GT';
                    } else if (ID == 14) {
                        location.href = 'https://k.weidian.com/TzBCa3qa ';

                    } else {
                        alert("补货中！！！！")
                    }
                    // 					var num = $(".centent_number").val();
                    // 					//最后的数量
                    // 					var seleCen = $('.Selection .lb').text();
                    // 					if (seleCen == "平装") {
                    // 						seleCen = 2;
                    // 					}
                    // 					var json = [];
                    // 					$('.SubscribeMoreP input:checked').each(function() {
                    // 						var xzid = $(this).attr('id'); //选中id
                    // 						json.push(xzid)
                    // 					})
                    // 					var xuanZId = json.join(",");
                    //
                    // 					$.ajax({
                    // 						type: "POST",
                    // 						url: "http://www.ynresearch.net/addcart",
                    // 						data: {
                    // 							"mid": ID,
                    // 							"num": num,
                    // 							'type': seleCen,
                    // 							'periods': xuanZId
                    // 						},
                    // 						headers: {
                    // 							"TOKEN": token
                    // 						},
                    // 						success: function(data) {
                    // 							var result = JSON.stringify(data);
                    // 							console.log(result);
                    // 							console.log(data)
                    // 							if (data.bol == true) {
                    // 								console.log(data.bol);
                    // 								location.href = './cart.html';
                    // 							}
                    // 						},
                    // 						error: function() {
                    // 							console.log("错误！！！")
                    //
                    // 						}
                    // 					})
                }
            })




