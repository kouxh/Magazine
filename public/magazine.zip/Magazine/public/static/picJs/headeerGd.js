$(document).ready(function(e) {
	$('#header_pcD').navfix(0, 999);
});
$('.gb').click(function() {
	$('.Home-section2').css({
		"display": "none"
	});
	$('.Home-section3').css({
		"margin-top": "40px"
	})
})
