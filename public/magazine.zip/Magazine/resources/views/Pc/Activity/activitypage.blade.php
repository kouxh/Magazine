<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>活动杂志</title>
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <meta name="author" content="元年科技股份有限公司" />
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <meta name="format-detection" content="telephone=no" />
    <link rel="stylesheet" href="/static/picss/pic.css">
    <link rel="stylesheet" href="/static/css/activity.css">
    <link rel="stylesheet" href="/static/picss/footer_header.css">
</head>
@include('Pc.layout.header');
<body>

<div class="wapper">
    <a href="/"  style="width: 100%; height:30rem;display: block;"><img src="/static/picImG/1.jpg" alt="" style="width: 100%; height: 100%;"></a>
    <div class="clear"></div>
</div>
{{--<script src="static/picJs/footer.js" type="text/javascript" charset="utf-8"></script>--}}

</body>
@include('Pc.layout.footer');
</html>
<script type="text/javascript" src="/static/js/jquery.1.7.2.min.js"></script>
{{--<script src="static/js/index_pc.js" type="text/javascript" charset="utf-8"></script>--}}
{{--<script src="static/picJs/headeerGd.js" type="text/javascript" charset="utf-8"></script>--}}

