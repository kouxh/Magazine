<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>活动-内容杂志</title>
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <meta name="author" content="元年科技股份有限公司" />
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <meta name="format-detection" content="telephone=no" />
    <link rel="stylesheet" href="/static/css/activity_content.css">
    <link rel="stylesheet" href="/static/picss/pic.css">
    <link rel="stylesheet" href="/static/picss/footer_header.css">
    <link rel="stylesheet" href="/static/css/paging.css">
<body>
<div class="wapper">
    <div class="conter">
        <dl>
            <dt><img src="{{ $data['desc'] -> img  }}" alt=""></dt>
            <dd>
                <h3>{{ $data['desc'] -> title }} </h3>
                <p class="p1"><span>{{ $data['desc'] -> start_at }}  -  {{ $data['desc'] -> end_at }}</span><span>限制<b>{{ $data['desc'] -> limit_num }}</b>人</span><span>{{ $data['desc'] -> address }}</span></p>
                <p>主办：<span>{{ $data['desc'] -> host }}</span></p>
                <p>协办：<span>{{ $data['desc'] -> co_sponsor }}</span> </p>
                <p><a class="bm">{{ $data['desc'] -> status }}</a> <span class="span_l"><a href="">收藏</a>/<a href="">分享</a></span></p>
            </dd>
        </dl>
    </div>
    <section>
        <div class="sectionL">
            <h2 class="sectionL_h2">
                <span class="span1"></span>
                <span class="span2">活动票种</span>

                @if($data['desc'] -> ticket == 0)
                    <span class="span3">免费票</span>
                @else
                    <span class="span3">收费票</span>
                @endif

            </h2>

            <p class="xt"></p>
            <div class="sectionL_1">
                <h2 class="section_H2">活动详情描述</h2>

                <p>{{ $data['desc'] -> describe }}</p>
            </div>


                <div class="sectionL_2" style="display: none">
                    <div class="sectionL_2l">
                        <h2 class="section_H2">精彩瞬间</h2>
                        <ul>
                            @foreach($data['moment'] as $v)
                                <li>
                                    <a href="#" target="_blank"> {{ $v -> title }}</a>
                                    <b>作者：<span>{{ $v -> author }}</span></b>
                                </li>
                            @endforeach

                            @if(!$data['moment'])
                                <a href="" class="ckgd" target="_blank">查看更多</a>
                                <div class="clear"></div>
                            @endif
                        </ul>
                    </div>

                    <div class="sectionL_2r">
                        <h2 class="section_H2">专业内容</h2>
                        <ul>
                            @foreach($data['food'] as $v)
                                <li>
                                    <a href="#" target="_blank"> {{ $v -> title }}</a>
                                    <b>作者：<span>{{ $v -> author }}</span></b>
                                </li>
                            @endforeach

                            @if(!$data['moment'])
                                <a href="" class="ckgd" target="_blank">查看更多</a>
                                <div class="clear"></div>
                            @endif
                        </ul>
                    </div>
                </div>



                <div class="sectionL_2" >
                    <div class="sectionL_2l">
                        <h2 class="section_H2">精彩瞬间</h2>
                        <ul>
                            @foreach($data['moment'] as $v)
                                <li>
                                    <a href="#" target="_blank"> {{ $v -> title }}</a>
                                    <b>作者：<span>{{ $v -> author }}</span></b>
                                </li>
                            @endforeach

                            @if(!$data['moment'])
                                <a href="" class="ckgd" target="_blank">查看更多</a>
                                <div class="clear"></div>
                            @endif
                        </ul>
                    </div>

                    <div class="sectionL_2r">
                        <h2 class="section_H2">专业内容</h2>
                        <ul>
                            @foreach($data['food'] as $v)
                                <li>
                                    <a href="#" target="_blank"> {{ $v -> title }}</a>
                                    <b>作者：<span>{{ $v -> author }}</span></b>
                                </li>
                            @endforeach

                            @if(!$data['moment'])
                                <a href="" class="ckgd" target="_blank">查看更多</a>
                                <div class="clear"></div>
                            @endif
                        </ul>
                    </div>
                </div>


            <div class="sectionL_3">
                <h2 class="section_H2">您还可能感兴趣</h2>

                @foreach( $data['relevant'] as $v)
                    <a href="/activitydesc/{{ $v -> id }}" target="_blank" class="hd">
                        <dl>
                            <dt><img src="{{ $v -> img }}" alt="">
                            </dt>
                            <dd>
                                <h3>{{ $v -> title }}</h3>
                                <p><span class="span1">{{ $v -> start_at }}</span><span class="span2">{{ $v -> address }}</span></p>
                            </dd>
                        </dl>
                    </a>
                @endforeach


                <div class="claer"></div>
            </div>
            <div class="claer"></div>
            <div class="sectionL_4" style="display: ">
                <h2 class="section_H2">活动详情描述</h2>
                <!-- <input type="text"> -->
                <div class="textarea form-control">
                    <textarea id="comment_text_box" placeholder="评论区"></textarea>
                </div>
                <button type="button" class="tj">提交</button>
                <div class="clear"></div>
            </div>
            <div class="sectionL_4 two" style="display: ">
                <h2 class="section_H2">全部讨论</h2>
                <!-- <input type="text"> -->
                <div class="textarea form-control">
                    <textarea id="comment_text_box" placeholder="评论区"></textarea>
                </div>
            </div>
        </div>
        <div class="sectionR">
            <!-- 活动地点 -->
            <div class="sectionR_1" style="display: ">
                <h2 class="h2">活动地点</h2>
                <div class="dt" >
                    <div style="margin-left: 40px;margin-top: 30px;">
                        <img src="{{ $data['desc'] -> ad_img }}" alt="" style="width: 230px;height: 300px;">
                    </div>

                </div>
            </div>
            <!-- 活动主办方 -->
            <div class="sectionR_2">
                <div class="sectionR_two ">
                    <h2 class="h2">活动主办方</h2>
                    <div class="sectionR_twoUL">
                        <b class="bj"></b>
                        @foreach($data['host'] as $v)
                        <dl>
                            <dt><img src="{{ $v -> img }}" alt=""></dt>
                            <dd>
                                <h3>{{ $v -> title }}</h3>
                                <p> {{ $v -> describe }}</p>
                            </dd>
                        </dl>
                        @endforeach

                    </div>
                </div>
            </div>

            @if(!$data['news'])
                <div class="sectionR_3">
                    <div class="sectionR_two">
                        <h2 class="h2">活动新闻</h2>
                        <div class="sectionR_twoUL">
                            <b class="bj"></b>
                            <div class="ul">
                                @foreach($data['news'] as $v)
                                    <li>
                                        <a href="#" target="_blank"> {{ $v -> title }}</a>
                                        <b>作者：<span>{{ $v -> author }}</span></b>
                                    </li>
                                @endforeach
                                    @if(!$data['news'])
                                        <a href="" class="ckgd" target="_blank">查看更多</a>
                                        <div class="clear"></div>
                                    @endif
                            </div>
                        </div>
                    </div>
                </div>
            @endif
        </div>
    </section>
</div>
</body>
</html>
