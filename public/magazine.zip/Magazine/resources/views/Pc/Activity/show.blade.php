<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>活动杂志</title>
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <meta name="author" content="元年科技股份有限公司" />
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <meta name="format-detection" content="telephone=no" />
    <link rel="stylesheet" href="/static/picss/pic.css">
    <link rel="stylesheet" href="/static/css/activity.css">
    <link rel="stylesheet" href="/static/picss/footer_header.css">
    <link rel="stylesheet" href="/static/css/paging.css">
</head>
<body>
<script src="/static/picJs/header.js" type="text/javascript" charset="utf-8"></script>
<div class="wapper">
    <div class="auto-width">
        <div class="feature-head-bottom-left flex">
            <span class="border-line" style=""></span>
            <div class="city-select" style="">
                <p class="city-info flex">全国<span class="icon icon-down"></span></p>
                <div class="select-down-div">
                    <div class="select-down-div-item flex city-present-item">
                        <span class="city-type">当前定位城市:</span>
                        <div class="city-present"><a>北京</a></div>
                    </div>
                    <div class="select-down-div-item flex"><span class="city-type">热门城市:</span>
                        <div class="city-list">
                            <a href="">北京</a>
                            <a href="">上海</a>
                            <a href="">广州</a>
                            <a href="">深圳</a>
                            <a href="">杭州</a>
                            <a href="">武汉</a>
                            <a href="">成都</a>
                            <a href="">长沙</a>
                            <a href="" target="_blank">南京</a>
                            <a href="" target="_blank">重庆</a>
                            <a href="" target="_blank">苏州</a>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="select-down-div-item flex"><span class="city-type">其它城市:</span>
                        <div class="city-list">
                            <a href="https://wh.huodongxing.com/events?city=西安" target="_blank">西安</a>
                            <a href="https://wh.huodongxing.com/events?city=郑州" target="_blank">郑州</a>
                            <a href="https://wh.huodongxing.com/events?city=厦门" target="_blank">厦门</a>
                            <a href="https://wh.huodongxing.com/events?city=天津" target="_blank">天津</a>
                            <a href="https://wh.huodongxing.com/events?city=宁波" target="_blank">宁波</a>
                            <a href="https://wh.huodongxing.com/events?city=青岛" target="_blank">青岛</a>
                            <a href="https://wh.huodongxing.com/events?city=东莞" target="_blank">东莞</a>
                            <a href="https://wh.huodongxing.com/events?city=佛山" target="_blank">佛山</a>
                            <a href="https://wh.huodongxing.com/events?city=济南" target="_blank">济南</a>
                            <a href="https://wh.huodongxing.com/events?city=珠海" target="_blank">珠海</a>
                            <a href="https://wh.huodongxing.com/events?city=合肥" target="_blank">合肥</a>
                            <a href="https://wh.huodongxing.com/events?city=福州" target="_blank">福州</a>
                            <a href="https://wh.huodongxing.com/events?city=石家庄" target="_blank">石家庄</a>
                            <a href="https://wh.huodongxing.com/events?city=昆明" target="_blank">昆明</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="feature-head-bottom-right flex">
            <div class="search-div-wrap">
                <div class="search-div flex">
                    <input class="js-search-input" type="text" placeholder="搜索活动或主办方名称" value="" />
                    <a class="search-link"><span class="icon search-top-icon"></span>搜索</a>
                </div>
                <div class="history-list">
                    <a href="" target="_blank">数字化转型</a>
                    <a href="" target="_blank">财务共享</a>
                    <a href="" target="_blank">管理会计</a>
                    <a href="" target="_blank">BI</a>
                </div>
            </div>
        </div>
    </div>
    <div class="clear"></div>
    <div class="banner"><img src="/static/img/07.jpg" alt=""></div>
    <section>
        <div class="sectionL">
            <div class="sectionL1">
                <h2 class="sectionL_h2"><span class="span1"></span><span class="span2">推荐活动</span></h2>
                <div class="">

                    @foreach($data['activity'] as $v)
                        <a href="/activitydesc/{{ $v -> id }}" class="hd">
                            <dl>
                                <dt><img src="{{ $v -> img }}" alt="">
                                    <span class="span1">{{ $v -> status }}</span>
                                </dt>
                                <dd>
                                    <h3>{{ $v -> title }}</h3>
                                    <p><span class="span1">{{ $v -> start_at }}</span><span class="span2">{{ $v -> address }}</span></p>
                                </dd>
                            </dl>
                        </a>
                    @endforeach

                    <div class="clear"></div>
                </div>
                <a href="" class="gdhd">更多活动</a>
                <div class="clear"></div>
            </div>
            <div class="sectionL2" >
                <h2 class="sectionL_h2"><span class="span1"></span><span class="span2">精彩瞬间</span></h2>
                <b class="bj"></b>
                <div class="Home-section4_c  D_1" id="jcsj">
                    <div class="Home-section4_cB">
                        <ul class="ul">

                            @foreach( $data['moment'] as $v)
                                <li id="">
                                    <a href="{{ $v -> id }}">
                                        <img src="{{ $v -> img }}" alt="">
                                        <h3>{{ $v -> title }}</h3>
                                    </a>
                                    <b>作者：<span>{{ $v -> author }}</span></b>
                                </li>
                            @endforeach

                            <a href="/activity" class="ckgd" style="float: right;">查看更多</a>
                        </ul>
                    </div>
                </div>
                <div class="clear"></div>
                <a href="" class="gdhd">更多活动</a>
            </div>
            <div class="sectionL3 sectionL1">
                <div class="tab">
                    <div class="tab-menu sectionL_h2">
                        <!-- <h2 class="">案例研究</h2> -->
                        <ul>
                            <li class="change">主办</li>
                            <li>合办</li>
                            <li>其他</li>
                        </ul>
                    </div>
                    <div class="clear"></div>
                    <div class="tab-box">
                        <div class="div">

                            @foreach( $data['host'] as $v)
                                <a href="/activitydesc/{{ $v -> id }}" class="hd">
                                    <dl>
                                        <dt><img src="{{ $v -> img }}" alt="">
                                            <span class="span1">{{ $v -> status }}</span>
                                        </dt>
                                        <dd>
                                            <h3>{{ $v -> title }}</h3>
                                            <p><span class="span1">{{ $v -> start_at }}</span><span class="span2">{{ $v -> address }}</span></p>
                                        </dd>
                                    </dl>
                                </a>
                            @endforeach

                        </div>
                        <div class="div">

                            @foreach( $data['co_sponsor'] as $v)
                                <a href="/activitydesc/{{ $v -> id }}" class="hd">
                                    <dl>
                                        <dt><img src="{{ $v -> img }}" alt="">
                                            <span class="span1">{{ $v -> status }}</span>
                                        </dt>
                                        <dd>
                                            <h3>{{ $v -> title }}</h3>
                                            <p><span class="span1">{{ $v -> start_at }}</span><span class="span2">{{ $v -> address }}</span></p>
                                        </dd>
                                    </dl>
                                </a>
                            @endforeach

                        </div>
                        <div class="div">

                            @foreach( $data['other'] as $v)
                                <a href="/activitydesc/{{ $v -> id }}" class="hd">
                                    <dl>
                                        <dt><img src="{{ $v -> img }}" alt="">
                                            <span class="span1">{{ $v -> status }}</span>
                                        </dt>
                                        <dd>
                                            <h3>{{ $v -> title }}</h3>
                                            <p><span class="span1">{{ $v -> start_at }}</span><span class="span2">{{ $v -> address }}</span></p>
                                        </dd>
                                    </dl>
                                </a>
                            @endforeach

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="sectionR" >
            <div class="sectionR_two">
                <h2 class="h2">活动新闻</h2>
                <div class="sectionR_twoUL">
                    <b class="bj"></b>
                    <div class="ul">

                        @foreach($data['news'] as $v)
                            <li>
                                <a href="#" target="_blank"> {{ $v -> title }} </a>
                                <b>作者：<span>{{ $v -> author }}</span></b>
                            </li>
                        @endforeach

                        <a href="" class="ckgd">查看更多</a>
                        <div class="clear"></div>
                    </div>
                </div>
            </div>
            <div class="sectionR_two">
                <h2 class="h2">专业内容</h2>
                <div class="sectionR_twoUL">
                    <b class="bj"></b>
                    <div class="ul">

                        @foreach( $data['food'] as $v)
                            <li>
                                <a href="#" target="_blank"> {{ $v -> title }}</a>
                                <b>作者：<span>{{ $v -> author }}</span></b>
                            </li>
                        @endforeach

                        <a href="" class="ckgd">查看更多</a>
                        <div class="clear"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- <script src="picJs/footer.js" type="text/javascript" charset="utf-8"></script> -->
</body>
</html>
<script type="text/javascript" src="/static/js/jquery.1.7.2.min.js"></script>
<script src="/static/js/index_pc.js" type="text/javascript" charset="utf-8"></script>
{{--<script src="/static/picJs/headeerGd.js" type="text/javascript" charset="utf-8"></script>--}}
 <script type="text/javascript" charset="utf-8">
	$('.city-info').on('click', function() {
		$('.select-down-div').toggle();
	});
	$().ready(function() {
		$(".tab-menu li").click(function(index) {
		    console.log("ddd")
			//通过 .index()方法获取元素下标，从0开始，赋值给某个变量
			var _index = $(this).index();
			//让内容框的第 _index 个显示出来，其他的被隐藏
			$(".tab-box>div").eq(_index).show().siblings().hide();
			//改变选中时候的选项框的样式，移除其他几个选项的样式
			$(this).addClass("change").siblings().removeClass("change");
		});
	});
</script>
