<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>理论前沿-管理会计研究</title>
    <meta name="description" content="" />
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <meta name="format-detection" content="telephone=no" />
    <!-- 公共css -->
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <link rel="stylesheet" href="/static/picss/footer_header.css">
    <link rel="stylesheet" href="/static/picss/pic.css">
    <!--  -->
    <link rel="stylesheet" type="text/css" href="/static/css/ll.css" />
</head>
@include('Pc.layout.header')
<body>
{{--<script src="static/picJs/header.js" type="text/javascript" charset="utf-8"></script>--}}
<div class="wapper" id="wapper">
    <div class="Home-section2">
        <img src="/static/img/08.jpg" alt="" class="pc">
        <img src="/static/picImG/yd/public/02.jpg" alt="" class="yd">
        <a class="Home-section2-bg"  href="http://www.yuanian.com/gz/hdfm/1786/">
            <span class="gb"></span>
        </a>
    </div>
    <section>
        <div class="sectionL">
            <b class="bj"></b>
            <div class="sectionLb">
                <h2>理论前沿</h2>
                <ul id="biuuu_city_list">

                    @foreach($data['list'] as $v)
                        <a class="wznr" href="/articledesc1/{{ $v['id'] }}" id="m_id88">
                            <dl>
                                <dt>
                                    <img src="http://www.chinamas.cn/{{$v -> img}}" alt="">
                                </dt>
                                <dd>
                                    <h3>{{ $v -> title }}</h3>
                                    <p>{{ $v -> message }}</p>
                                    <b>
                                        <div class="b-sL">
                                            <span>理论前沿</span>
                                        </div>
                                        <div class="b-sR">
                                            <span>{{ $v -> author }}</span>
                                            <span>{{ $v -> crea_at }}</span>
                                        </div>
                                    </b>
                                </dd>
                            </dl>
                        </a>
                    @endforeach

                    {{ $data['list'] -> appends(['mode'=>'observation']) -> links('Common.pagination')  }}


                </ul>
                <div class="clear"></div>
                <div id="pagge" class="pagge"></div>
            </div>
        </div>
        <div class="sectionR">
            <div class="sectionR_two">
                <h2 class="h2">猜你喜欢</h2>
                <div class="sectionR_twoUL sectionR_twoUL1">
                    <b class="bj"></b>
                    <div class="clear"></div>
                    <div class="ul">

                        @foreach($data['like'] as $v)
                            <li>
                                <a href="/articledesc1/{{$v -> id}}" id="like1">{{ $v -> title }}</a>
                                <b>作者：<span>{{ $v -> author }}</span></b>
                            </li>
                        @endforeach

                    </div>
                </div>
            </div>
            <div class="clear"></div>
            <div class="sectionR_two">
                <h2 class="h2">观察</h2>
                <div class="sectionR_twoUL sectionR_twoUL2">
                    <b class="bj"></b>
                    <div class="ul">

                        @foreach($data['observation'] as $v)
                            <li>
                                <a href="/articledesc1/{{$v -> id}}">{{ $v -> title }}</a>
                                <b>作者：<span>{{ $v -> author }}</span></b>
                            </li>
                        @endforeach

                        <a href="articleList1?mode=observation" class="ckgd">查看更多</a>
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="sectionR_one">
                <b class="bj"></b>

                <div class="gc_bottomRD">
                    <h3><span class="D_Rbspan1">{{$data['magazine'] -> year}}</span>{{$data['magazine'] -> title}}</h3>
                    <h4>邮发代码：80-841</h4><img src="http://www.chinamas.cn/{{$data['magazine'] -> cover_img}}" alt="">
                    <a href="/magazinedesc/{{ $data['magazine'] -> m_id }}" class="msyd">马上阅读</a>
                    <a href="/magazine" class="ckgd">更多阅读</a>
                </div>

                <a class="wytg">我要投稿</a>
            </div>
            <div class="clear"></div>
        </div>
        <div class="clear"></div>
    </section>
    <div class="Home-section4" id="industry_section4">
        <div class="Home-section4_c  D_1" id="limit">
            <h2>人物</h2>
            <b class="bj"></b>
            <div class="Home-section4_cB">
                <ul class="ul">

                    @foreach($data['interview'] as $k => $v)
                        <li id="interview{{$v -> img}}">
                            <a href="/articledesc1/{{$v -> id}}">
                                <img src="http://www.chinamas.cn{{ $v -> img }}" alt="">
                                <h3>{{ $v -> title }}</h3>
                            </a>
                            <b>作者：<span>{{ $v -> author }}</span></b>
                        </li>
                    @endforeach

                    <a href="/articleList1/interview" class="ckgd" >查看更多</a>
                </ul>
            </div>
        </div>

{{--        <div class="gc_bottomL gc_bottomL3">--}}
{{--            <h2 class="h2">活动</h2>--}}
{{--            <b class="bj"></b>--}}
{{--            <div class="gc_bottomLUL">--}}
{{--                <div class="ul">--}}

{{--                   --}}

{{--                    <div class="clear"></div>--}}
{{--                </div>--}}
{{--                --}}{{--                            <a href="/activity" class="ckgd">查看更多</a>--}}
{{--                <div class="clear"></div>--}}
{{--            </div>--}}
{{--        </div>--}}
        <div class="Home-section4_l Right ">
            <h2>活动</h2>
            <b class="bj"></b>
            <ul>

                <li>
                    <a href="/summit">2019管理会计国际高峰论坛</a>
                    <b>开始时间：<span>2019-09-21</span></b>
                </li>

                <li>
                    <a href="/selection">中国本土管理会计2019十大案例评选</a>
                    <b>开始时间：<span>2019-07-15</span></b>
                </li>

                <div class="clear"></div>

        <a href="/activity" class="ckgd">查看更多</a>
            </ul>
        </div>
    </div>
</div>
{{--<script src="static/picJs/footer.js" type="text/javascript" charset="utf-8"></script>--}}
</body>
@include('Pc.layout.footer')
</html>
<script type="text/javascript" src="/static/js/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="/static/js/jquery.1.7.2.min.js"></script>
<script src="/static/layui/layui.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/gt.js"></script>
{{--<script type="text/javascript" src="static/json/llist.js"> </script>--}}
{{--<script src="static/js/index_pc.js" type="text/javascript" charset="utf-8"></script>--}}
{{--<script src="static/picJs/headeerGd.js" type="text/javascript" charset="utf-8"></script>--}}
<!-- 公共 -->
<script type="text/javascript" src="/static/picJs/wytg.js"> </script>
<script src="/static/picJs/ydheader.js" type="text/javascript" charset="utf-8"></script>

