<html>
<head>
    <meta charset="UTF-8" />
    <title>观察-管理会计研究</title>
    <meta name="description" content="">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <meta name="format-detection" content="telephone=no" />
    <!-- 公共css -->
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <link rel="stylesheet" href="/static/picss/pic.css">
    <link rel="stylesheet" href="/static/picss/footer_header.css">
    <!--  -->
    <link rel="stylesheet" type="text/css" href="/static/css/gc.css" />

</head>
@include('Pc.layout.header')
<body>
<script src="/static/picJs/header.js" type="text/javascript" charset="utf-8"></script>
<div class="wapper" id="wapper">
    <div class="Home-section2">
        <img src="/static/img/08.jpg" alt="" class="pc">
        <img src="/static/picImG/yd/public/02.jpg" alt="" class="yd">
        <a class="Home-section2-bg"  href="http://www.yuanian.com/gz/hdfm/1786/">
            <span class="gb"></span>
        </a>
    </div>
    <section>
        <div class="sectionL">
            <b class="bj"></b>
            <div class="sectionLb" id="">
                <h2>观察</h2>
                <ul id="biuuu_city_list">

                    @foreach($data['list'] as $v)
                        <a class="wznr" href="/articledesc1/{{ $v['id'] }}" id="m_id87">
                            <dl class="gc_dl"><dt>
                                    <img src="http://www.chinamas.cn/{{ $v -> img }}" alt="">
                                </dt>
                                <dd>
                                    <h3>{{ $v -> title }}</h3>
                                    <p>{{ $v -> message }}</p>
                                    <b>
                                        <div class="b-sL">
                                            <span>观察</span>
                                        </div>
                                        <div class="b-sR">
                                            <span>{{ $v -> author }}</span>
                                            <span>{{ $v -> crea_at }}</span>
                                        </div>
                                    </b>
                                </dd>
                            </dl>
                        </a>
                    @endforeach

                {{ $data['list'] -> appends('/observation') -> links('Common.pagination')  }}

                </ul>
                <div class="clear"></div>



            </div>
        </div>
        <div class="sectionR">
            <div class="sectionR_one">
                <h2 class="h2">热搜词</h2>
                <div class="sectionR_oneA">
                    <a href="javascript:;" >管理会计报告</a>
                    <a href="javascript:;">预算管理</a>
                    <a href="javascript:;" >成本管理</a>
                    <a href="javascript:;" >财务共享</a>
                    <a href="javascript:;" >大数据</a>
                    <a href="javascript:;" >人工智能</a>
                    <a href="javascript:;" >税务管理</a>
                    <a href="javascript:;" >CFO</a>
                    <a href="javascript:;" >商业智能</a>
                    <a href="javascript:;" >数字化转型</a>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="sectionR_two">
                <h2 class="h2">理论前沿</h2>
                <div class="sectionR_twoUL sectionR_twoUL2">
                    <b class="bj"></b>
                    <div class="ul">

                        @foreach( $data['frontier'] as $v)
                            <li>
                                <a href="/articledesc1/{{ $v['id'] }}" id="frontier86">{{ $v -> title }} </a>
                                    <b>作者：<span>{{ $v -> author}}</span></b>

                            </li>
                        @endforeach

                        <a href="/articleList1/frontier" class="ckgd">查看更多</a>
                        <div class="clear"></div>
                    </div>
                </div>
            </div>
            <div class="clear"></div>
            <div class="sectionR_two">
                <h2 class="h2">业界</h2>
                <div class="sectionR_twoUL sectionR_twoUL3">
                    <b class="bj"></b>
                    <div class="ul">

                        @foreach($data['industry'] as $v)
                            <li>
                                <a href="/articledesc1/{{ $v['id'] }}" id="industry1">{{ $v -> title }}</a>
                                <b>作者：<span>{{ $v -> author }}</span></b>
                            </li>
                        @endforeach

                        <a href="/articleList1/industryNews" class="ckgd">查看更多</a>
                        <div class="clear"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clear"></div>
    </section>
    <div class="gc_bottom">
        <div class="gc_bottomL gc_bottomL1">
            <h2 class="h2">新技术</h2>
            <b class="bj"></b>
            <div class="gc_bottomLUL">
                <div class="ul">
                    @foreach($data['technigue'] as $v)
                        <li>
                            <a href="/articledesc1/{{ $v['id'] }}" id="technigue88">{{ $v -> title }}</a>
                            <b>作者：<span>{{ $v -> author }}</span></b>
                        </li>
                    @endforeach


                    <div class="clear"></div>
                </div>
                <a href="/articleList1/frontier" class="ckgd">查看更多</a>
                <div class="clear"></div>
            </div>
        </div>
        <div class="gc_bottomL gc_bottomL2" id="limit">
            <h2 class="h2">人物</h2>
            <b class="bj"></b>
            <div class="gc_bottomLUL">
                <div class="ul">


                    @foreach($data['interview'] as $v)
                    <li>
                    <a href="/articledesc1/{{ $v['id'] }}" id="technigue88">{{ $v -> title }}</a>
                    <b>作者：<span>{{ $v -> author }}</span></b>
                    </li>
                    @endforeach

                </div>
                <div class="clear"></div>

                <a href="/articleList1/frontier" class="ckgd">查看更多</a>
                <div class="clear"></div>
            </div>
        </div>

        <div class="gc_bottomL gc_bottomL3">
                        <h2 class="h2">活动</h2>
                        <b class="bj"></b>
                        <div class="gc_bottomLUL">
                            <div class="ul">

                                <li>
                                    <a href="/summit">2019管理会计国际高峰论坛</a>
                                    <b>开始时间：<span>2019-09-21</span></b>
                                </li>

                                <li>
                                    <a href="/selection">中国本土管理会计2019十大案例评选</a>
                                    <b>开始时间：<span>2019-07-15</span></b>
                                </li>

                                <div class="clear"></div>
                            </div>
{{--                            <a href="/activity" class="ckgd">查看更多</a>--}}
                            <div class="clear"></div>
                        </div>
        </div>

{{--        <div class="Home-section4_l Right ">--}}
{{--            <h2>活动</h2>--}}
{{--            <div class="bj"></div>--}}
{{--            <div class="section5r_lB">--}}
{{--                <ul>--}}
{{--                    <li>--}}
{{--                        <a href="/summit">2019管理会计国际高峰论坛</a>--}}
{{--                        <b>开始时间：<span>2019-09-21</span></b>--}}
{{--                    </li>--}}

{{--                    <li>--}}
{{--                        <a href="/selection">中国本土管理会计2019十大案例评选</a>--}}
{{--                        <b>开始时间：<span>2019-07-15</span></b>--}}
{{--                    </li>--}}

{{--                    <div class="clear">--}}
{{--                    </div>--}}
{{--                </ul>--}}
{{--            </div>--}}
{{--        </div>--}}

{{--        <div class="gc_bottomL gc_bottomL3">--}}
{{--            <h2 class="h2">活动</h2>--}}
{{--            <b class="bj"></b>--}}
{{--            <div class="gc_bottomLUL">--}}
{{--                <div class="ul">--}}

{{--                    @foreach($data['activity'] as $v)--}}
{{--                        <li>--}}
{{--                            <a href="/activitydesc/{{ $v ->id }}">{{ $v -> title }}</a>--}}
{{--                            <b>开始时间：<span>{{ $v -> start_at }}</span></b>--}}
{{--                        </li>--}}
{{--                    @endforeach--}}

{{--                    <div class="clear"></div>--}}
{{--                </div>--}}
{{--                <a href="/activity" class="ckgd">查看更多</a>--}}
{{--                <div class="clear"></div>--}}
{{--            </div>--}}
{{--        </div>--}}
        <div class="gc_bottomR">
            <h2 class="h2">杂志</h2>
            <b class="bj"></b>
            <div class="gc_bottomRD">

                <h3><span class="D_Rbspan1">2019年</span>第四期 总第07期</h3>
                <h4>邮发代码：80-841</h4>
                <img src="http://www.chinamas.cn/upload/2019/08/23/15665434883390.png" alt="">
                <a href="/magazinedesc/{{ $data['magazine'] -> m_id }}" class="msyd">马上阅读</a>
                <a href="/magazine" class="ckgd">更多阅读</a>

            </div>
        </div>
        <div class="clear"></div>
    </div>
    <div class="clear"></div>
</div>
</body>
@include('Pc.layout.footer')
</html>
<!-- js 公共 -->
<script type="text/javascript" src="/static/js/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="/static/js/jquery.1.7.2.min.js"></script>
<script src="/static/layui/layui.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/gt.js"></script>
<script src="/static/js/index_pc.js" type="text/javascript" charset="utf-8"></script>
<script src="/static/picJs/headeerGd.js" type="text/javascript" charset="utf-8"></script>
<script src="/static/picJs/ydheader.js" type="text/javascript" charset="utf-8"></script>

<!--  -->
{{--<script src="static/json/gclist.js"></script>--}}

