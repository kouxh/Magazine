<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <meta name="author" content="元年科技股份有限公司" />
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <meta name="format-detection" content="telephone=no" />
    <!-- <link rel="stylesheet" type="text/css" href="css/Magazine.css" /> -->
    <link rel="stylesheet" href="/static/picss/footer_header.css">
    <link rel="stylesheet" href="/static/picss/pic.css">

    <title>杂志-管理会计研究</title>
</head>
<style>
    section{
        width: 1158px;
        margin: 0  auto;
    }
    .main{
        margin-top: 44px;
    }
    .main .zzlist_title  {
        font-size: 26px;
        font-weight: 500;
        color:#141718;
        padding-bottom: 19px;
        border-bottom: 1px solid #ececec;
    }
    .main .M_a {
        width: 178px;
        display: inline-block;
        margin-right: 12px;
        margin-top: 30px;
        margin-bottom: 45px;    cursor: pointer;
    }
    .main .M_a:nth-last-child(1){
        margin-right: 0px;
    }
    .main .M_a dl {
        width: 100%;
        height: 100%;
        background: rgba(255, 255, 255, 1);
        border: 1px solid rgba(238, 238, 238, 1);
        float: left;
    }

    .main dl dt {
        width: 100%;
        margin: 0 auto;
        text-align: center;
    }

    .main dl dt img {
        width: 150px;
        text-align: center;
        height: 194px;
        margin-top: 10px;
        margin-bottom: 10px;
    }
    .main dl dd {
        width: 172px;
        margin: 0 auto;
        text-align: center;
        width: 172px;
        height: 40px;
        font-size: 14px;
        font-weight: 500;
        color: rgba(43, 51, 65, 1);
        line-height: 25px;
    }
</style>
@include('Pc.layout.header')
<body>

<div class="wapper">
    <div class="Home-section2">
        <img src="/static/img/08.jpg" alt="" class="pc">
        <!-- <img src="img/0002.png" alt="" class="yd"> -->
        <a class="Home-section2-bg"  href="http://www.yuanian.com/gz/hdfm/1786/">
            <span class="gb"></span>
        </a>
    </div>
    <section>
        <div class="main">

            @foreach($data as $k => $v)
                <div class="main_ main1">
                    <p class="zzlist_title">{{ $k }}</p>
                    @foreach($v as $key => $val)
                        <a href="magazinedesc/{{ $val -> m_id}}" class="M_a">
                            <dl>
                                <dt><img src="http://www.chinamas.cn{{ $val -> cover_img }}" alt=""></dt>
                                <dd>{{ $val -> year }}{{ $val -> title }}</dd>
                            </dl>
                        </a>
                    @endforeach

                    <div class="clear"></div>
                </div>
            @endforeach

        </div>
    </section>
</div>


</body>
@include('Pc.layout.footer')
</html>
<script src="http://www.jq22.com/jquery/jquery-1.10.2.js"></script>
<script type="text/javascript" src="/static/js/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="/static/js/jquery.1.7.2.min.js"></script>
{{--<script src="static/js/index_pc.js" type="text/javascript" charset="utf-8"></script>--}}
{{--<script src="static/picJs/headeerGd.js" type="text/javascript" charset="utf-8"></script>--}}
{{--<script type="text/javascript" src="static/json/zzlist.js"> </script>--}}

