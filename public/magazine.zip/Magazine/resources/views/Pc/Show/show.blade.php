<!DOCTYPE html>
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <meta name="author" content="元年科技股份有限公司" />
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <meta name="format-detection" content="telephone=no" />
    <meta name="description" content="管理会计研究网高度关注财务转型、数字化转型浪潮中我国会计领域的理论演进和企事业单位的管理实践和新技术应用，深入诠释与持续传播实用案例、智能技术应用和前沿理论，为管理会计人搭建一个经验交流、互动学习的专业平台。" />
    <link rel="stylesheet" href="/static/swiperCss/swiper.min.css">
    <link rel="stylesheet" type="text/css" href="/static/css/Home.css" />
    <link rel="stylesheet" href="https://g.alicdn.com/de/prismplayer/2.8.0/skins/default/aliplayer-min.css" />
    <script type="text/javascript" charset="utf-8" src="https://g.alicdn.com/de/prismplayer/2.8.0/aliplayer-min.js"></script>
    <title>管理会计研究</title>
    <link rel="stylesheet" href="/static/picss/pic.css">
    <link rel="stylesheet" href="/static/picss/footer_header.css">
    <link rel="import" href="/static/tips/header.html" id="page1" />
</head>
@include('Pc.layout.header')
<body>

<div class="wapper" id="wapper">
    <div class="banner"><img src="static/img/07.jpg" alt="" class="pc_banner"><img src="static/picImG/yd/public/01.jpg" alt="" class="yd_banner"></div>
    <section>
        <div class="Home-section1" id="Home-section1">
            <div class="Home-section1D">
                <div class="Home-section1D_l D_ Gc">
                    <h2>观察</h2>

                    <div class="Gc_1">
                        @foreach($data['observation'] as $k => $v)
                            <a href="/articledesc1/{{$v -> id}}" class="gc">
                                <dl id="observation{{$v -> id}}">
                                    <dt><img src="http://www.chinamas.cn/{{ $v -> img }}" alt=""></dt>
                                    <dd>
                                        <p class="title">{{$v -> title}}</p >
                                        <p class="message">{{$v -> message}}</p >
                                        <p class="p2">{{ $v -> crea_at }}</p >
                                    </dd>
                                </dl>
                            </a>
                        @endforeach
                        <a href="articleList1/observation" class="ck">查看更多</a>
                    </div>

                </div>
                <div class="Home-section1D_C D_ jD">
                    <h2>荐读</h2>
                    @foreach($data['recommended'] as $k => $v)
                        <dl id="recommended{{$v -> id}}">
                            <a href ="articledesc1/{{$v -> id}}">
                                <dt><img src="{{ $v -> img }}" alt=""></dt>
                                <dd>
                                    <p class="title">{{$v -> title}}</p >
                                </dd>
                            </a>
                        </dl>
                    @endforeach

                     <div class="clear"></div>
                </div>
                <div class="Home-section1D_l D_ Xw2">
                    <h2>新闻</h2>
                    <ul>
                        @foreach($data['news'] as $k => $v)
                            <li id="yjwz{{$v -> id}}">
                                <a href="/newsdesc/{{$v -> id}}">
                                    <p class="p1">{{$v -> title}}</p >
                                    <p class="p3">{{$v -> message}}</p >
                                    <p class="p2">{{$v -> crea_at}}</p >
                                </a>
                            </li>
                        @endforeach
                        <a href="/news" class="ck">查看更多</a>
                    </ul>
                </div>

            </div>
        </div>
        <!-- Home-section1 end -->
        <!-- <b class="bj"></b> -->
        <div class="Home-section2">
            <img src="static/img/08.jpg" alt="" class="pc">
            <img src="/static/picImG/yd/public/02.jpg" alt="" class="yd">
            <div class="Home-section2-bg">
            </div>
        </div>
        <div class="Home-section3">
            <div class="Home-section3_l">
                <b class="bj"></b>
                <div class="Home-section3_lB">
                    <h2>理论前沿</h2>
                    <div class="section3_lB section3_lB1">
                        <ul>

                            @foreach($data['frontier'] as $k => $v)
                                <li>
                                    <a href="articledesc1/{{$v -> id}}">{{$v -> title}}</a>
                                    <b>作者：<span>{{$v -> author}}</span></b>
                                </li>
                            @endforeach

                            <div class="clear"></div>
                        </ul>
                        <a href="articleList1/frontier" class="ck">查看更多</a>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="Home-section3_l  ">
                <b class="bj"></b>
                <div class="Home-section3_lB">
                    <h2>案例研究</h2>
                    <div class="section3_lB  section3_lB2">
                        <ul>

                            @foreach($data['case_list'] as $k => $v)
                                <li>
                                    <a href="articledesc1/{{$v -> id}}">{{$v -> title}}</a>
                                    <b>作者：<span>{{$v -> author}}</span></b>
                                </li>

                            @endforeach

                            <div class="clear"></div>
                        </ul>
                        <a href="articleList1/research" class="ck">查看更多</a>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="Home-section3_l  ">
                <b class="bj"></b>
                <div class="Home-section3_lB">
                    <h2>新技术</h2>
                    <div class="section3_lB section3_lB3">
                        <ul>

                            @foreach($data['technigue'] as $k => $v)
                                <li>
                                    <a href="articledesc1/{{$v -> id}}">{{$v -> title}}</a>
                                    <b>作者：<span>{{$v -> author}}</span></b>
                                </li>
                            @endforeach

                         <div class="clear"></div>
                        </ul>
                        <a href="articleList1/technigue" class="ck">查看更多</a>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
        <div class="clear"></div>
        <div class="Home-section4">
            <div class="Home-section4_c  D_1">
                <h2>专访</h2>
                <b class="bj"></b>
                <div class="Home-section4_cB">

                    <ul class="ul">
                        @foreach($data['interview'] as $k => $v)
                            <li id="interview{{$v -> img}}">
                                <a href="articledesc1/{{$v -> id}}">
                                    <img src="http://www.chinamas.cn{{ $v -> img }}" alt="">
                                    <h3>{{ $v -> title }}</h3>
                                </a>
                                <b>作者：<span>{{ $v -> author }}</span></b>
                            </li>
                        @endforeach
                        <a href="articleList1/interview" class="ckgd">查看更多</a>
                    </ul>
                </div>
            </div>
            <div class="Home-section4_l Right D_1">
                <h2>杂志</h2>
                <b class="bj"></b>
                <div class="Home-section1D_Rb">
                    <h3><span class="D_Rbspan1">{{$data['magazine'] -> year}}</span> {{$data['magazine'] -> title}} </h3>
                    <h4>邮发代码：80-841</h4>
                    <img src="http://www.chinamas.cn{{$data['magazine'] -> cover_img}}" alt="">
                    <a href="/magazinedesc/{{ $data['magazine'] -> m_id }}" class="btn_a">马上阅读</a>
                    <a href="/magazine" class="btn_a2">更多阅读</a>
                </div>
            </div>
        </div>
        <div class="clear"></div>
        <div class="Home-section5">
            <div class="bj"></div>
            <div class="Home-section5D">
                <div class="Home-section5l">
                    <h2>人物</h2>
                    <div class="Home-section5l_b">
                        <dl>
                            <dt><img src="/static/picImG/index/01.jpg"></dt>
                            <dd>顾惠忠：北京航空航天大学国际金融专业硕士，长江商学院EMBA，研究员级高级会计师</dd>
                        </dl>
                        <dl>
                            <dt><img src="/static/picImG/index/02.jpg"></dt>
                            <dd>肖泽忠：英国CardiffUniversity会计学教授，北京工商大学北京市特聘讲座教授，英国ACCA 研究委员会委员，中国审计学会理事会理事</dd>
                        </dl>
                        <dl>
                            <dt><img src="/static/picImG/index/03.jpg"></dt>
                            <dd>李守武：中国兵器装备集团公司副总经理</dd>
                        </dl>
                        <dl>
                            <dt><img src="/static/picImG/index/04.jpg"></dt>
                            <dd>汤谷良：经济学博士，现任对外经贸大学国际商学院院长，博士生导师</dd>
                        </dl>

                        <dl>
                            <dt><img src="/static/picImG/index/05.jpg"></dt>
                            <dd>北京大学光华管理学院会计系副教授、博士生导师，北京大学会计专业硕士项目（MPAcc）执行主任</dd>
                        </dl>

                        <dl>
                            <dt><img src="/static/picImG/index/06.jpg"></dt>
                            <dd>Rajiv Banker 美国Temple University Fox商学院会计教授</dd>
                        </dl>
                        <div class="clear"></div>
                    </div>
                    <a href="/bigshot" class="ck">更多专家</a>
                    <div class="clear"></div>
                </div>
                <div class="Home-section5r">
                    <div class="bj"></div>
                    <h2>活动</h2>
                    <div class="section5r_lB">
                        <ul>

                            <li>
                                <a href="/summit">2019管理会计国际高峰论坛</a>
                                <p>开始时间：<span>2019-09-21</span></p>
                            </li>

                            <li>
                                <a href="/selection">中国本土管理会计2019十大案例评选</a>
                                <p>开始时间：<span>2019-07-15</span></p>
                            </li>
                            
                            <div class="clear">
                            </div>
                        </ul>
{{--                        <a href="/activity" class="ck">查看更多</a>--}}
                    </div>
                </div>
{{--                <div class="Home-section5r">--}}
{{--                    <div class="bj"></div>--}}
{{--                    <h2>活动</h2>--}}
{{--                    <div class="section5r_lB">--}}
{{--                        <ul>--}}

{{--                            @foreach($data['activity'] as $k => $v)--}}
{{--                                <li>--}}
{{--                                    <a href="/activitydesc/{{ $v ->id }}">{{$v -> title}}</a>--}}
{{--                                    <p>开始时间：<span>{{ $v -> start_at }}</span></p>--}}
{{--                                </li>--}}
{{--                             @endforeach--}}

{{--                            <div class="clear">--}}
{{--                            </div>--}}
{{--                        </ul>--}}
{{--                        <a href="/activity" class="ck">查看更多</a>--}}
{{--                    </div>--}}
{{--                </div>--}}
            </div>
        </div>
    </section>
</div>

</body>

</html>
@include('Pc.layout.footer')
<script src="/static/js/jquery-1.11.1.min.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/jquery.1.7.2.min.js"></script>
<script type="text/javascript" src="/static/js/gt.js"></script>
<script src="/static/js/index_pc.js" type="text/javascript" charset="utf-8"></script>
<script src="/static/picJs/ydheader.js" type="text/javascript" charset="utf-8"></script>

{{--<script src="static/picJs/headeerGd.js" type="text/javascript" charset="utf-8"></script>--}}
