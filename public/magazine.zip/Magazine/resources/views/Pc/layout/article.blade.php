<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
</head>
<body>
<div class="Bottom-share">
    <div class="Bottom-share_mian">
        <div class="share" data-cmd="more"></div>
        <div class="Return-Top" id="to_top" style="left: 282px; top: 2652px;"></div>
        <div class="Collection"></div>
    </div>
    <div class="shelf-layer " id="shelf-layer">
        <div class="share-top"><a href="#" class="close-layer"><i class="icon-arrow-l"></i></a><strong>分享</strong></div>
        <div class="share-post bdsharebuttonbox bdshare-button-style0-32" data-bd-bind="1568599948046">
            <dl>
                <dt><a class="bds_weixin" data-cmd="weixin"></a></dt>
                <dd>微信</dd>
            </dl>
            <dl>
                <dt><a class="bds_tsina" data-cmd="tsina"></a></dt>
                <dd>微博</dd>
            </dl>
            <dl>
                <dt><a class="bds_douban" data-cmd="douban"></a></dt>
                <dd>豆瓣</dd>
            </dl>
            <!-- <ul class="justify-flex">
                <li class="child">

                    <span><i class="icon-sina"></i></span></li>

            </ul> -->
        </div>
    </div>
</div>
</body>
</html>


