<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="/static/picss/footer_header.css">
</head>
<body>
<div class="footer" id="footer">
    <div class="footerD">
        <div class="footerLeft">
            <ul>
                <li><a class="footer-bt">学术支持单位</a></li>
                <li><a class="footer-bt">中国人民大学管理会计研究中心</a></li>
                <li><a class="footer-bt">上海财经大学管理会计项目研究中心</a></li>
                <li><a class="footer-bt">江苏管理会计研究中心</a></li>
                <li><a class="footer-bt">元年管理会计研究院</a></li>
            </ul>
            <ul>
                <li><a class="footer-bt">战略合作单位</a></li>
                <li><a class="footer-bt">中国医药会计学会</a></li>
                <li><a class="footer-bt">上海市成本研究会</a></li>
            </ul>
            <ul>
                <li><a class="footer-bt">关于<img src="/static/img/32.png" alt=""></a></li>
                <li><a class="footer-bt">关于我们</a></li>
                <li><a class="footer-bt">联系方式：400-819-1255</a></li>
            </ul>
        </div>
        <div class="footerRight">
            <dl>
                <dt><img src="/static/picImG/header-footer/footer.jpg" alt=""></dt>
                <dd>官方微信</dd>
            </dl>

        </div>
    </div>
    <div class="footerB">
        <p>
            <a href="/flsm" class="flsm">法律声明</a>  北京元年诺亚舟咨询有限公司版权所有 京ICP备08000903 京公网安备110102004356
        </p>
    </div>
</div>
<div class="footer_yd">
    <div class="footer_yd_main">
        <div class="footer_tab">
            <div class="footer_tab-menu">
                <p class="Collapsing"><label for="">学术支持单位</label><span>+</span></p>
                <div class="coll_body">
                    <ul>
                        <li><a class="footer-bt">中国人民大学管理会计研究中心</a></li>
                        <li><a class="footer-bt">上海财经大学管理会计项目研究中心</a></li>
                        <li><a class="footer-bt">江苏管理会计研究中心</a></li>
                        <li><a class="footer-bt">元年管理会计研究院</a></li>
                    </ul>
                </div>
                <p class="Collapsing"><label for="">战略合作单位</label><span>+</span></p>
                <div class="coll_body">
                    <ul>
                        <li><a class="footer-bt">中国医药会计学会</a></li>
                        <li><a class="footer-bt">上海市成本研究会</a></li>
                    </ul>
                </div>
                <p class="Collapsing" ><label>关于<img src="/static/img/32.png" alt=""></a></label><span>+</span></p>
                <div class="coll_body">
                    <ul>
                        <li><a class="footer-bt">关于我们</a></li>
                    </ul>
                </div>

            </div>

        </div>
        <div class="contact">联系方式：400-819-1255</div>
        <p class="paragraph">
            <a href="/flsm.html" class="flsm">法律声明</a><span>北京元年科技股份有限公司版权所有</span><span>京ICP备08000903 京公网安备110102004356</span>

        </p>
        <dl>
            <dt><img src="/static/picImG/header-footer/footer.jpg" alt=""></dt>
            <dd>官方微信</dd>
        </dl>

    </div>
</div>
</body>
</html>
<script type="text/javascript" src="static/js/jquery-1.11.1.min.js"></script>
<script type="text/javascript">
    $().ready(function() {
        $(".Collapsing").click(function() {
            $(this).toggleClass("current").siblings('.Collapsing').removeClass("current"); //切换图标
            $(this).next(".coll_body").slideToggle(500).siblings(".coll_body").slideUp(500);
        });
    });
    //自动推送
    (function(){
        var bp = document.createElement('script');
        var curProtocol = window.location.protocol.split(':')[0];
        if (curProtocol === 'https') {
            bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
        }
        else {
            bp.src = 'http://push.zhanzhang.baidu.com/push.js';
        }
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(bp, s);
    })();

</script>
