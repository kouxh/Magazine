{{--@yield('header')--}}
<div class="sxts" id="sxts">
    <div id="sxts_main">
        <p>本网是<a href="http://www.sino-ma.org/" target="_blank">管理会计网（www.sino-ma.org）</a>的升级版，试运行阶段新老网站将并行至9月30日，网站正在努力完善中，若给大家造成不便，敬请谅解。
        </p>
        <p>如您在浏览网站过程中发现任何问题或有好的建议，欢迎反馈给我们！（<a href="https://www.wjx.top/jq/44785972.aspx">点击反馈</a>）</p>
    </div>
</div>
<div class="header_pc" id="header_pc">
    <div class="header_pcD" id="header_pcD">
        <div class="header_pcB" id="header_pcB">
            <a href="/" class="loge"><img src="/static/img/logo2.png" alt=""></a>
            <ul class="header_pcBU">
                <li><a href="/articleList1/industry" >业界</a></li>
                <li><a href="/articleList1/observation" >观察</a></li>
                <li><a href="/articleList1/frontier" >理论前沿</a></li>
                <li><a href="/articleList1/research" >案例研究</a></li>
                <li><a href="/articleList1/technigue" >新技术</a></li>
                <li><a href="/articleList1/interview" >人物</a></li>
                <li><a href="/articleList1/practice" >实践</a></li>
{{--                <li><a href="/activity" >活动</a></li>--}}
                <li><a href="/magazine" >杂志</a></li>
                <!-- <li><a href="../cmas/industry.html" target="_blank">专家团队</a></li> -->
            </ul>
            <div class="header_pcBUr">
                <form action="">
                    <input type="text" placeholder="搜索">
                    <button></button>
                </form>

                @if(!Session::get('users'))
                    <div class="NOzc">
                        <ul>
                            <li><a href="/loadLogin" >登录</a></li>
                            <li><a href="/loadRegister" >注册</a></li>
                        </ul>
{{--                        <a href="/magation" class="dg">订购</a>--}}
                    </div>
                @else
                    <div class="Gmheader_pcB">

                        <p class="Tc"><span class="Tc_user">你好：<span id="login">{{ Session::get('users') -> account }}</span></span><label for="">|<span class="" onclick="outlogin()">退出</span></label></p>
                    </div>
                @endif

            </div>
            <div class="clear"></div>
        </div>
        <div class="clear"></div>
    </div>
</div>
<div class="yd_header">
    <div class="yn_main">
        <div class="yn_motop">
            <div class="yn_motop_left">
                <a  class="search"><img src="/static/picImG/yd/public/03.png" alt=""></a>
                <a href="/loadLogin" class="personal"><img src="/static/picImG/yd/public/05.png" alt=""></a>
            </div>
            <div class="yn_motop_center">
                <a href="/" class="motop_logo"><img src="/static/img/logo2.png"></a>
            </div>
            <div class="yn_motop_right">
                <div class="three  col1">
                </div>
            </div>
        </div>
        <div class="mo_dropmenu">
            <ul>
                <li class="">
                    <div class="mo_dropmenu_title">
                        <a href="/articleList1/industry" >业界</a>
                    </div>
                </li>
                <li>
                    <div class="mo_dropmenu_title">
                        <a href="/articleList1/observation" >观察</a>
                    </div>

                </li>
                <li>
                    <div class="mo_dropmenu_title">
                        <a href="/articleList1/frontier" >理论前沿</a>
                    </div>
                </li>
                <li>
                    <div class="mo_dropmenu_title">
                        <a href="/articleList1/research" >案例研究</a>
                    </div>

                </li>
                <li>
                    <div class="mo_dropmenu_title">
                        <a href="/articleList1/technigue" >新技术</a>
                    </div>

                </li>
                <li>
                    <div class="mo_dropmenu_title">
                        <a href="/articleList1/interview" >人物</a>
                    </div>

                </li>
                <li>
                    <div class="mo_dropmenu_title">
                        <a href="/articleList1/practice" >实践</a>
                     </div>
                </li>
                <li>
                    <div class="mo_dropmenu_title">
                        <a href="/activity" >活动</a>

                    </div>
                </li>
                <li>
                    <div class="mo_dropmenu_title">
                        <a href="/magazine" >杂志</a>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>
<script type="text/javascript" src="/static/js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="/static/picJs/tuichu.js"></script>

<script>
    function outlogin() {

        $.get('/outlogin' , {} ,function(data){
                if(data.bol == true){
                    alert('退出成功');
                    window.location.reload();
                }
        })
    }
</script>



