<?php
/*
|--------------------------------------------------------------------------
| Home Routes
|--------------------------------------------------------------------------
|
| Here is where you can register Home routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "Home" middleware group. Now create something great!
|
*/

/*登陆*/
Route::get('/home/login' , 'Home\LoginController@login');

/*执行登陆*/
Route::post('/home/loginDo' , 'Home\LoginController@loginDo');

/*登陆中间件*/
Route::group(['middleware' => ['checkLogin']], function() {

    /*首页*/
    Route::get('/home/index' , 'Home\IndexController@index');
    Route::get('/home/welcome' , 'Home\IndexController@welcome');

    /*文章*/
    Route::get('/home/LoadList' , 'Home\Article@LoadList');
    Route::get('/home/PageList' , 'Home\Article@PageList');
    Route::get('/home/LoadAdd' , 'Home\Article@LoadAdd');
    Route::post('/home/DoAdd' , 'Home\Article@DoAdd');
    Route::get('/home/DoDelete' , 'Home\Article@DoDelete');
    Route::get('/home/SeeShow' , 'Home\Article@SeeShow');
    Route::get('/home/LoadEdit' , 'Home\Article@LoadEdit');
    Route::post('/home/DoEdit' , 'Home\Article@DoEdit');

    /*杂志*/
    Route::get('/home/magazineList' , 'Home\Magazine@magazineList');
    Route::get('/home/magazinPage' , 'Home\Magazine@magazinPage');
    Route::get('/home/magazinAdd' , 'Home\Magazine@magazinAdd');
    Route::post('/home/MagazineDoAdd' , 'Home\Magazine@MagazineDoAdd');
    Route::get('/home/MagazineDoDelete' , 'Home\Magazine@MagazineDoDelete');
    Route::get('/home/MagazineEdit' , 'Home\Magazine@MagazineEdit');
    Route::post('/home/MagazineDoEdit' , 'Home\Magazine@MagazineDoEdit');


    /*活动*/
    Route::get('/home/artivityList' , 'Home\Activity@artivityList');
    Route::get('/home/artivityPage' , 'Home\Activity@artivityPage');
    Route::get('/home/artivityAdd' , 'Home\Activity@artivityAdd');
    Route::post('/home/artivityDoAdd' , 'Home\Activity@artivityDoAdd');
    Route::get('/home/artivityEdit' , 'Home\Activity@artivityEdit');
    Route::post('/home/artivityDoEdit' , 'Home\Activity@artivityDoEdit');
    Route::get('/home/artivityDel' , 'Home\Activity@artivityDel');
    Route::get('/home/artivityShow' , 'Home\Activity@artivityShow');

    /*新闻*/
    Route::get('/home/newsList' , 'Home\News@newsList');
    Route::get('/home/newsPage' , 'Home\News@newsPage');
    Route::get('/home/newsAdd' , 'Home\News@newsAdd');
    Route::post('/home/newsDoAdd' , 'Home\News@newsDoAdd');
    Route::get('/home/newsEdit' , 'Home\News@newsEdit');
    Route::post('/home/newsDoEdit' , 'Home\News@newsDoEdit');
    Route::get('/home/newsDel' , 'Home\News@newsDel');

    /*干货列表*/
    Route::get('/home/foodList' , 'Home\Food@foodList');
    Route::get('/home/foodPage' , 'Home\Food@foodPage');
    Route::get('/home/foodAdd' , 'Home\Food@foodAdd');
    Route::post('/home/foodDoAdd' , 'Home\Food@foodDoAdd');
    Route::get('/home/foodEdit' , 'Home\Food@foodEdit');
    Route::post('/home/foodDoEdit' , 'Home\Food@foodDoEdit');
    Route::get('/home/foodDel' , 'Home\Food@foodDel');

    /*精彩瞬间*/
    Route::get('/home/momentList' , 'Home\Moment@momentList');
    Route::get('/home/momentPage' , 'Home\Moment@momentPage');
    Route::get('/home/momentAdd' , 'Home\Moment@momentAdd');
    Route::post('/home/momentDoAdd' , 'Home\Moment@momentDoAdd');
    Route::get('/home/momentEdit' , 'Home\Moment@momentEdit');
    Route::post('/home/momentDoEdit' , 'Home\Moment@momentDoEdit');
    Route::get('/home/momentDel' , 'Home\Moment@momentDel');

    /*栏目管理*/
    Route::get('/home/columnList' , 'Home\Column@columnList');
    Route::get('/home/columnPage' , 'Home\Column@columnPage');
    Route::get('/home/columnAdd' , 'Home\Column@columnAdd');
    Route::get('/home/columnDoAdd' , 'Home\Column@columnDoAdd');
    Route::get('/home/columnEdit' , 'Home\Column@columnEdit');
    Route::get('/home/columnDoEdit' , 'Home\Column@columnDoEdit');
    Route::get('/home/columnDel' , 'Home\Column@columnDel');



});

/*上传图片*/
Route::post('uploadImg' , 'Home\UploadImg@uploadImg');