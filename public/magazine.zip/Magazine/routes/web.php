<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



/*发送验证码*/
Route::get('code','Service\SendCode@sendCode');

/*调试  ---- 加载兴趣页面*/
Route::get('interest','Pc\RegController@Interest');

/*加载兴趣词*/
Route::get('loadKeyword','Pc\RegController@loadKeyword');

/*调试 ---- 加载注册页面*/
Route::get('loadRegister','Pc\RegController@loadRegister');

/*验证码登陆*/
Route::post('codelogin','Pc\LoginController@codeLogin');

/*调试 ---- 加载登陆页面*/
Route::get('loadLogin','Pc\LoginController@loadLogin');

/*登陆*/
Route::post('login','Pc\LoginController@login');

/*调试 ---- 首页页面*/
Route::get('/','Pc\ShowController@showPage');



/**
 * 文章订单
 */

Route::get('choiceMode','Pc\ArticleOrderController@choiceMode');


/**
 * 文章开始
 */

Route::get('articlelist' , 'Pc\ArticleController@articleList');

Route::get('articledesc' , 'Pc\ArticleController@articleDesc');


/*调试   -----  业界列表*/
Route::get('/articleList1/{mode}' , 'Pc\ArticleController@articleList1');

Route::get('/articledesc1/{id}' , 'Pc\ArticleController@articleDesc1');


/*大咖*/
Route::get('bigshot' , 'Pc\ArticleController@bigShot');


/*新闻*/
Route::get('/news' , 'Pc\NewsController@newsList');

/*详情*/
Route::get('/newsdesc/{id}' , 'Pc\NewsController@newsDesc');

/**
 * 文章结束
 */

/*活动*/
Route::get('/activity' , 'Pc\ActivityController@show');

Route::get('/activitydesc/{id}' , 'Pc\ActivityController@desc');




/*调试----------加载杂志首页*/
Route::get('magazine','Pc\MazationController@magazineShow');

/*加载更多杂志*/
Route::get('showmore','Pc\MazationController@showMore');

/*加载杂志详情*/
Route::get('magazinedesc/{id}','Pc\MazationController@magazineDesc');



/*加载购物车列表*/
Route::get('cart','Pc\CartController@Cart');

/*购物车*/
Route::get('cartlist','Pc\CartController@cartList');

/*加入购物车*/
Route::post('addcart','Pc\CartController@addCart');

/*购物车删除*/
Route::get('delcart','Pc\CartController@delCart');

/*加减购物车*/
Route::get('changeCrat','Pc\CartController@changeCrat');

/*生成订单*/
Route::post('careorder' , 'Pc\OrderController@careOrder');

/*订单列表*/
Route::get('orderlist' , 'Pc\OrderController@orderList');

/*收款二维码*/
Route::get('creaCode' , 'Wechat\PatternTwoPay@creaCode');

/*异步通知*/
Route::post('notify_url' , 'Wechat\WechatNotily@notify_url');

/*同步通知*/
Route::get('refreshorder' , 'Wechat\WechatNotily@RefreshOrder');


/**
 * 个人中心开始
 */
/*新建收获地址*/
Route::post('creaaddress' , 'Pc\UserController@creaAddress');

/*退出登陆*/
Route::get('outlogin' , 'Pc\UserController@OutLogin');

/*验证修改密码*/
Route::post('Verification' , 'Common\EditController@Verification');

/*修改密码*/
Route::post('editpass' , 'Common\EditController@editPass');

/*个人中心首页*/
Route::get('homePage' , 'Pc\UserController@homePage');

/*基本信息修改*/
Route::post('basicInfo' , 'Pc\UserController@basicInfo');

/*积分详情*/
Route::get('integralDesc' , 'Pc\UserController@integralDesc');

/*我的订单*/
Route::get('myOrder' , 'Pc\UserController@myOrder');

/*我的关注*/
Route::get('myFollow' , 'Pc\UserController@myFollow');

/*编辑关注*/
Route::get('editFollow' , 'Pc\UserController@editFollow');

/*执行编辑关注*/
Route::post(' ' , 'Pc\UserController@editDoFollow');

/*我要投稿*/
Route::get('contribute' , 'Pc\UserController@Contribute');

/*成为会员*/
Route::get('becomeVip' , 'Pc\UserController@becomeVip');

/*收获地址*/
Route::get('myAddress' , 'Pc\UserController@myAddress');

/*编辑地址*/
Route::get('editAddress' , 'Pc\UserController@editAddress');

/*执行编辑地址*/
Route::post('editDoAddress' , 'Pc\UserController@editDoAddress');

/*设置默认地址*/
Route::get('setAddress' , 'Pc\UserController@setAddress');

/*下载文件*/
Route::get('downloadFile' , 'Pc\UserController@downloadFile');


/**
 * 个人中心结束
 */



/*
 * 活动
 * */

Route::get('/summit' , 'Pc\ActivityController@summit');

Route::get('/selection' , 'Pc\ActivityController@selection');



/*公共*/
Route::get('/flsm' , 'Pc\ShowController@flsm');

/*服务协议*/
Route::get('/fwxy' , 'Pc\ShowController@fwxy');
///**
// * 测试二维码
// */
//Route::get('testCode' , 'Pc\UserController@testCode');





///*注册*/
//Route::post('register','Pc\RegController@register');
//
///*杂志列表*/
//Route::get('magationlist','Pc\MazationController@mazationList');
//
///*杂志详情*/
//Route::get('magationdesc','Pc\MazationController@mazationDesc');





